Windows native ONNX Runtime 1.32.0, GeForce RTX 3060 12 GiB, WoW foreground.
control-live/60 = audio.py and f5engine.py from ac5d783, with the same benchmark as release-live/60.
release-live/60 = 6ecfda8 product code. Benchmark with configurable idle gap from 8a7e212.
*-live: 3 clicks of the local addon test button, full muted playback to the real endpoint.
*-60: one separate cold phrase, then 30 short / 30 long different Russian phrases and three voices;
the device receives the first half-second of each packet. All PCM samples checked before muting.
release-corpus: same release, --full-playback --wow-corpus --pairs 2 --wow-gap 15.
final-cuda/control-cuda: the same local button test with plain CUDA and full playback, no TensorRT.
All *.jsonl: first line is startup metadata. Subsequent lines use Windows QPC seconds or durations in ms.
pcm-comparison.json: differences between matched release and control WAVs in signed PCM16 units.
results.json and timings.json: interim experiments and the final matched comparison.
stock = ac5d783 MME; normal = normal GPU priority; wasapi = shared WASAPI on Windows default endpoint;
warm = additional synthesis then 12 s idle; earlyfeed = WGC before loading plus 12 s idle;
paced = 12 ms after each step; headroom = 12 ms only if >600 ms of prior audio remains;
queued = await GPU on the last transformer step; repeat = experimental in-memory phrase cache;
shipped = WASAPI + cache before audio priming; audioprime = silent shared stream kept active;
pulse = start then stop shared audio before first synthesis; ondemand = hold only throughout first synthesis;
timer = timeBeginPeriod(1); mmcss = set synth thread to MMCSS Audio during its first synthesis;
control/final = matched full-playback button sessions; control-corpus/final-corpus = matched 60 phrases.
FPS uses complete inter-Present intervals within each synthesis window on the main WoW swap chain.
frames.csv uses zero-based trial indices and has separate idle windows. foreground.json records focus changes.
